package K23cnt3.QxtWebBanSach.controller.admin;

public class QxtAdminProductController {
}
